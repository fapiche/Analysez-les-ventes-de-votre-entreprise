#Import des librairies
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import datetime
import seaborn as sns
import scipy.stats as st
from sklearn.linear_model import LinearRegression

#import des données
data = pd.read_csv('données/P4_03_transactions_clean.csv', encoding ='UTF_8')
transactions = data.copy()

#Attribution de variables aux noms des colonnes dans un soucis de maintenance
client_id = 'client_id'
sex = 'sex'
birth = 'birth'
id_prod = 'id_prod'
price = 'price'
categ = 'categ'
date = 'date'
session_id = 'session_id'

# Création d'un dataframe pour afficcher la courbe de Lorenz
def courbe_lorenz(data) :
    data = data.groupby(client_id).sum(price).sort_values(price).reset_index()
    part_client = int(len(data)/10)
    tab = []
    pourcent = 0
    for i in range(0, int(len(data) + 1), part_client) :
        data_i = data[data.index < i]
        montant = data_i[price].sum()
        montant = round( montant / data[price].sum() * 100, 2)
        tab.append([pourcent, montant])
        pourcent += 10
    data_lorenz = pd.DataFrame(tab, columns = ['% des clients', '% Montant'])
    return data_lorenz  

#Calcul du coefficient de Gini
def gini(lorenz) :
    old_x = 0
    old_y = 0
    gini = 0
    B = 0
    for index, row in lorenz.iterrows() :
        x = row['% des clients'] / 100
        y = row['% Montant'] / 100
        
        base = x - old_x
        hauteur = y - old_y
        
        aire_triangle = base * hauteur / 2
        aire_rectangle = base * old_y
        
        B += aire_triangle + aire_rectangle
        
        old_x = x
        old_y = y
    A = 1 * 1 / 2
    gini = 2 * (A - B)
    return gini

#On crée nos data pour générer notre courbe de lorenz et on calcul notre coefficient de Gini
data = transactions.copy()
lorenz = courbe_lorenz(data) 
gini(lorenz)

#On génére notre courbe de lorenz
depenses = transactions[transactions[price] > 0]
dep = +depenses[price].values
n = len(dep)
lorenz1 = np.cumsum(np.sort(dep)) / dep.sum()
lorenz1 = np.append([0],lorenz1) # La courbe de Lorenz commence à 0
fig = plt.figure(figsize=(10,7))
plt.axes().axis('equal')
plt.title('Répartition du montant dépensé par les clients')
xaxis = np.linspace(0-1/n,1+1/n,n+1) #Il y a un segment de taille n pour chaque individu, plus 1 segment supplémentaire d'ordonnée 0. Le premier segment commence à 0-1/n, et le dernier termine à 1+1/n.
plt.plot(xaxis,lorenz1,drawstyle='steps-post', label = "courbe de Lorenz")
a = [0,1]
b = a
plt.plot(a, b, c='r', label = 'égalité parfaite')
plt.legend()
plt.savefig('graphiques/P4_04_courbe_lorenz.png')
plt.show()

# Nombre de ventes par catégories 

fig = plt.figure(figsize =(10,7))
plt.title('Nombre de ventes par catégories', fontweight = 'bold')
plt.ylabel('Nombre de ventes')
plt.hist(transactions[categ])
plt.savefig('graphiques/P4_04_montant_vente_categorie_histo.png')
plt.show()

#On crée une boxplot pour avoir une visualisation des données concernant les montants des transactions
sns.boxplot(x = transactions[price]).set(title = 'Montant des transactions')
plt.savefig('graphiques/P4_04_montant_transactions.png')
plt.show()

# Représentation de série temporelle

#Vérification de la cohérence des dates
transactions[date] = pd.to_datetime(transactions[date])
mask1 = transactions[date] <= datetime.datetime.now()
transactions_now = transactions[mask1].reset_index()

# Ventes par mois 

#Préparation des données pour l'analyse graphique
transactions_mois = transactions.copy()
transactions_mois[date] = transactions_mois[date].dt.strftime('%Y/%m')
transactions_mois = transactions_mois[[date, price]].groupby(date).count().sort_values(date).reset_index()
transactions_mois.head()

sns.lineplot(x = date, y = price, data = transactions_mois).set(title = 'Nombre de ventes par mois avec valeurs aberrantes', ylabel = 'Nombre de ventes')
plt.savefig('graphiques/P4_04_nb_ventes_par_mois_avec_valeur_aberrantes.png')
plt.show()


transactions_mois = transactions_now.copy()
transactions_mois[date] = transactions_mois[date].dt.strftime('%Y/%m')
transactions_mois = transactions_mois[[date, price]].groupby(date).count().sort_values(date).reset_index()
transactions_mois.head()

sns.lineplot(x = date, y = price, data = transactions_mois).set(title = 'Nombre de ventes par mois sans valeurs aberrantes', ylabel = 'Nombre de ventes')
plt.savefig('graphiques/P4_04_Nombre_de_ventes_par_mois_sans_valeurs_aberrantes.png')
plt.show()

#  Montant des ventes par mois et par catégorie

#Préparation des données pour l'analyse graphique
montant_mois = transactions.copy()
montant_mois[date] = montant_mois[date].dt.strftime('%Y/%m')
montant_mois = montant_mois[[date, price]].groupby(date).sum().sort_values(date).reset_index()
sns.lineplot(x = date, y = price, data = montant_mois).set(title = 'Montant des ventes par mois avec valeurs aberrantes', ylabel = 'Montant des ventes')
plt.savefig('graphiques/P4_04_evolution_chiffre_affaire.png')
plt.show()

# Analyses bivariées

# Nombre de produits achetés par client par catégories

cat_moy_achat = transactions.copy()
cat_moy_achat = cat_moy_achat[[categ, client_id, price]]
cat_moy_achat = cat_moy_achat.groupby([categ, client_id]).count().reset_index()
cat_moy_achat = cat_moy_achat.rename(columns = {price : "Nombre de produits achetés par client"})

#Détection des outliers gràce à la loi interquartile
q1 = cat_moy_achat["Nombre de produits achetés par client"].quantile(0.25)
q3 = cat_moy_achat["Nombre de produits achetés par client"].quantile(0.75)
iqr = q3 - q1

cat_moy_achat_min = q1 - 1.5 * iqr
cat_moy_achat_max = q3 + 1.5 * iqr
cat_moy_achat = cat_moy_achat[cat_moy_achat["Nombre de produits achetés par client"] < cat_moy_achat_max]
cat_moy_achat = cat_moy_achat[cat_moy_achat["Nombre de produits achetés par client"] > cat_moy_achat_min]

sns.boxplot(x = categ, y = "Nombre de produits achetés par client", data = cat_moy_achat).set(title = "Nombre de produits achetés par client pour chaques catégories")
plt.savefig('graphiques/P4_04_nb_prod_par_client_par_catégorie_sans_outliers.png')
plt.show()

# Montant dépensé par client et par catégories

cat_montant_achat = transactions.copy()
cat_montant_achat = cat_montant_achat[[categ, client_id, price]]
cat_montant_achat = cat_montant_achat.groupby([categ, client_id]).sum(price).reset_index()
cat_montant_achat = cat_montant_achat.rename(columns = {price : "Montant dépensé par client"})

#Détection des outliers gràce à la loi interquartile
q1 = cat_montant_achat["Montant dépensé par client"].quantile(0.25)
q3 = cat_montant_achat["Montant dépensé par client"].quantile(0.75)
iqr = q3 - q1

cat_montant_achat_min = q1 - 1.5 * iqr
cat_montant_achat_max = q3 + 1.5 * iqr
cat_montant_achat = cat_montant_achat[cat_montant_achat["Montant dépensé par client"] < cat_montant_achat_max]
cat_montant_achat = cat_montant_achat[cat_montant_achat["Montant dépensé par client"] > cat_montant_achat_min]

sns.boxplot(x = categ, y = "Montant dépensé par client", data = cat_montant_achat).set(title = "Montant dépensé par client pour chaques catégories")
plt.savefig('graphiques/P4_04_montant_par_client_par_catégorie_sans_outliers.png')
plt.show()

# Chiffre d'affaire par tranche d'age


#création de tranche d'ages

age_ca = transactions.copy()
age_ca["Tranche d'ages"] = pd.cut(age_ca['age'], bins=[16,30,50,93], labels=['17-30 ans ', '30-50 ans ', '50-93ans'])
age_ca = age_ca[["Tranche d'ages", price]]
age_ca = age_ca.groupby("Tranche d'ages").sum(price).reset_index()

fig = plt.figure(figsize = (10, 7))
plt.title("Chiffre d'affaire par tranche d'ages", fontweight = 'bold')
plt.pie(age_ca[price], labels = age_ca["Tranche d'ages"].values, autopct = "%0.2f%%")
plt.savefig('graphiques/P4_04_ca_par_tranche_age.png')
plt.show()

# Mission 3

# Montant/age 

#On calcul l'age de nos clients pour simplifier notre analyse
transactions['age'] = datetime.datetime.now().year - transactions[birth]


montant_age = transactions.copy()
montant_age = montant_age.groupby('age').sum(price).reset_index()
montant_age = montant_age[['age', price]]

sns.regplot(x = 'age', y = price, data = montant_age).set(title = 'Montant dépensé par age')
plt.savefig('graphiques/P4_04_montant_depense_par_age_avec_outliers.png')
plt.show()

# Sexe/catégorie

sex_cat = transactions.copy()
sex_cat = sex_cat[[sex, categ]].pivot_table(index = categ, columns = sex, aggfunc= len).fillna(0).copy().astype(int)

sns.heatmap(data = sex_cat)
plt.savefig('graphiques/P4_04_sexe_clients_par_categorie.png')
plt.show()

# Age/fréquence d'achat

nb_achat_age = transactions.copy()
nb_achat_age = nb_achat_age[['age', client_id, session_id]].drop_duplicates()
nb_achat_age = nb_achat_age.groupby(['age', client_id]).count().reset_index()
nb_achat_age = nb_achat_age.groupby(['age']).mean(session_id).reset_index()
nb_achat_age = nb_achat_age.rename(columns = {session_id : "Fréquence d'achats"})

sns.regplot(x = 'age', y = "Fréquence d'achats", data = nb_achat_age).set(title = "Fréquence d'achats par age")
plt.savefig('graphiques/P4_04_frequence_achat_par_age_avec_outliers.png')
plt.show()

# Age/taille du panier moyen

age_moy_achat = transactions.copy()
age_moy_achat = age_moy_achat[['age', client_id, session_id]]
age_moy_achat = age_moy_achat.groupby(['age', session_id]).count().reset_index()
age_moy_achat = age_moy_achat.groupby('age').mean().reset_index()
age_moy_achat = age_moy_achat[['age', client_id]]
age_moy_achat= age_moy_achat.rename(columns = {client_id : "Taille du panier"})

sns.regplot(x = 'age', y = "Taille du panier", data = age_moy_achat).set(title = 'Taille du panier moyen par age')
plt.savefig('graphiques/P4_04_taille_panier_moyen_par_age.png')
plt.show()

# Age/catégories de produits achetés

age_cat = transactions.copy()
sns.boxplot(x = categ, y =  'age', data = age_cat).set(title = 'Age des clients par catégorie de produits')
plt.savefig('graphiques/P4_04_age_clients_par_categorie.png')
plt.show()


