#Import des librairies
import pandas as pd

#import des données
data = pd.read_csv('données/customers.csv', encoding ='UTF_8')
customers = data.copy()
data = pd.read_csv('données/products.csv', encoding ='UTF_8')
products = data.copy()
data = pd.read_csv('données/transactions.csv', encoding ='UTF_8')
transactions = data.copy()

#Attribution de variables aux noms des colonnes dans un soucis de maintenance
client_id = 'client_id'
sex = 'sex'
birth = 'birth'
id_prod = 'id_prod'
price = 'price'
categ = 'categ'
date = 'date'
session_id = 'session_id'

#Suppression des doublons dans le DataFrame transactions qui contient 126 doublons
transactions = transactions.drop_duplicates()

#On fusionne nos 3 Dataframe
transactions = transactions.merge(customers, how = 'left', on = 'client_id')
transactions = transactions.merge(products, how ='left', on = 'id_prod')

transactions = transactions.dropna()

#On remarque une valeur débutant par test que nous allons retirer de notre population
mask1 = transactions[date].str.startswith('20')
transactions = transactions[mask1]
transactions[date] = pd.to_datetime(transactions[date])

transactions[categ] = transactions[categ].astype(int)

transactions.to_csv('données/P4_03_transactions_clean.csv', encoding ='UTF_8')